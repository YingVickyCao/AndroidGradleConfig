# AndroidGradleConfig
Config about gradle
