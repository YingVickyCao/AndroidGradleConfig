package com.example.hades.calculator;

public class Calculator {
    public int sum(int a, int b) {
        return a + b;
    }
}
