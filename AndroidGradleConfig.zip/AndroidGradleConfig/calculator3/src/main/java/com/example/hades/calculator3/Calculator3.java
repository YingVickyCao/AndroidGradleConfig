package com.example.hades.calculator3;

public class Calculator3 {
    public int sum(int a, int b) {
        return a + b;
    }
}