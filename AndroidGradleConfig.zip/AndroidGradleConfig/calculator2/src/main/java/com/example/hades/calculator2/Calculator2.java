package com.example.hades.calculator2;

public class Calculator2 {
    public int sum(int a, int b) {
        return a + b;
    }
}